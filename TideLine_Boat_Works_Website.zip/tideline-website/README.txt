TideLine Boat Works Website

Files included:
- index.html
- style.css
- assets/tideline-logo.png

How to use:
1. Open index.html in a browser to preview.
2. Replace the phone number, email, and Instagram handle.
3. Add real project photos to the gallery section.
4. Upload the files to your website builder or hosting provider.

Suggested next edits:
- Add a real hero photo of a wakeboat.
- Replace placeholder gallery boxes with before-and-after images.
- Connect TideLineBoatWorks.com to this website.
